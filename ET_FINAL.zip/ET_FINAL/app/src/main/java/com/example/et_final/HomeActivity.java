package com.example.et_final;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity {

    DBHelper DB;
    Button addbtn;
    Button loginbtn;
    EditText ename;
    ArrayList<String> listItem;
    ArrayAdapter adapter;

    ListView elist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        DB = new DBHelper(this);
        loginbtn = (Button)findViewById(R.id.loginbtn);
        listItem = new ArrayList<>();

        addbtn = findViewById(R.id.addbtn);
        ename = findViewById(R.id.ename);

        elist = findViewById(R.id.eventeditlist);

        viewEvents();

        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });

        elist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String text = elist.getItemAtPosition(i).toString();
                Toast.makeText(HomeActivity.this, ""+text, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), EditFormActivity.class);
                startActivity(intent);
            }
        });
        
        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = ename.getText().toString();
                Boolean add = DB.addEvent(name);
                if(name.length() > 0){
                    Toast.makeText(HomeActivity.this, "Event Added", Toast.LENGTH_SHORT).show();
                    ename.setText("");
                    listItem.clear();
                    viewEvents();
                }
                else {
                    Toast.makeText(HomeActivity.this, "Event Not Added", Toast.LENGTH_SHORT).show();
                }
            }
        });


        //Initialize and Assign Variable
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_nav);

        //Set Home Selected
        bottomNavigationView.setSelectedItemId(R.id.home);

        //Perform ItemSelectListener
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.home:
                        return true;
                    case R.id.calendar:
                        startActivity(new Intent(getApplicationContext(), CalendarActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.edit:
                        startActivity(new Intent(getApplicationContext(), EditActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;
            }
        });
    }

    private void viewEvents(){
        Cursor cursor = DB.viewEvents();

        if (cursor.getCount() == 0){
            Toast.makeText(this, "No data to show", Toast.LENGTH_SHORT).show();
        }
        else {
            while(cursor.moveToNext()){
                listItem.add(cursor.getString(1));

            }

            adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listItem);
            elist.setAdapter(adapter);
        }
    }
}