package com.example.et_final;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.SimpleCursorAdapter;

import androidx.annotation.Nullable;

import java.util.Date;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DBNAME = "EventTracker.db";
    public static final String USERS_TABLE = "Users";
    public static final String EVENTS_TABLE = "Events_Table";

    //Columns
    private static final String ID = "ID";
    private static final String USERNAME = "USERNAME";
    private static final String PASSWORD = "PASSWORD";
    private static final String EVENT_NAME = "EVENT_NAME";
    private static final String DATE = "DATE";
    private static final String E_DETAILS = "E_DETAILS";

    //Create Tables
    private static final String CREATE_USERST = "CREATE TABLE " + USERS_TABLE + " (" +
            USERNAME + " TEXT PRIMARY KEY, " +
            PASSWORD + " TEXT)";

    private static final String CREATE_EVENTT = "CREATE TABLE " + EVENTS_TABLE + " (" +
            ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            EVENT_NAME + " TEXT, " + DATE + " TEXT, " + E_DETAILS + " TEXT)";


    public DBHelper(Context context) {
        super(context, DBNAME, null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase myDB) {
        myDB.execSQL(CREATE_USERST);
        myDB.execSQL(CREATE_EVENTT);
    }

    @Override
    public void onUpgrade(SQLiteDatabase myDB, int i, int i1) {
        myDB.execSQL("drop Table if exists " + USERS_TABLE);
        myDB.execSQL("drop Table if exists " + EVENTS_TABLE);
    }

    public Boolean insertData(String username, String password){
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(USERNAME, username);
        contentValues.put(PASSWORD, password);
        long result = myDB.insert(USERS_TABLE, null, contentValues);
        if(result==-1)
            return false;
        else
            return true;

    }

    public Boolean addEvent(String name, String date, String d){
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(EVENT_NAME, name);
        contentValues.put(DATE, date);
        contentValues.put(E_DETAILS, d);
        long result = myDB.insert(EVENTS_TABLE, null, contentValues);
        if (result == -1)
            return false;
        else
            return true;
    }

    public Boolean addEvent(String name){
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(EVENT_NAME, name);
        long result = myDB.insert(EVENTS_TABLE, null, contentValues);
        if (result == -1)
            return false;
        else
            return true;
    }

    public Boolean checkusername(String username){
        SQLiteDatabase myDB = this.getWritableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from users where username = ?", new String[]{username});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    public Boolean checkusernamepassword(String username, String password){
        SQLiteDatabase myDB = this.getWritableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from users where username = ? and password = ?", new String[]{username, password});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    //Create method to view data
    public Cursor viewEvents(){
        SQLiteDatabase myDB = this.getReadableDatabase();
        String query = "Select * from " + EVENTS_TABLE;
        Cursor cursor = myDB.rawQuery(query, null);

        return cursor;
    }

    public Boolean updateEvent(String orgname, String name, String date, String d){
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(EVENT_NAME, name);
        contentValues.put(DATE, date);
        contentValues.put(E_DETAILS, d);
        long result = myDB.update(EVENTS_TABLE, contentValues, "EVENT_NAME=?", new String[]{orgname});
        if (result == -1)
            return false;
        else
            return true;
        //myDB.close();
    }

}
