package com.example.et_final;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class EditActivity extends AppCompatActivity {

    EditText ename, ename2, edate, edetails;
    Button updatebtn;
    DBHelper DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        DBHelper DB = new DBHelper(this);
        ename = (EditText)findViewById(R.id.ename);
        ename2 = (EditText)findViewById(R.id.ename2);
        edate = (EditText)findViewById(R.id.edate);
        edetails = (EditText)findViewById(R.id.edetails);
        updatebtn = (Button)findViewById(R.id.updatebtn);



        updatebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String en = ename.getText().toString();
                String en2 = ename2.getText().toString();
                String ed = edate.getText().toString();
                String edet = edetails.getText().toString();

                Boolean update = DB.updateEvent(en, en2, ed, edet);
                if (update != false){
                    Toast.makeText(EditActivity.this, "Update Successful", Toast.LENGTH_SHORT).show();
                }
            }
        });


        //Initialize and Assign Variable
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_nav);

        //Set Home Selected
        //bottomNavigationView.setSelectedItemId(R.id.home);

        //Perform ItemSelectListener
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.home:
                        startActivity(new Intent(getApplicationContext(), HomeActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.calendar:
                        startActivity(new Intent(getApplicationContext(), CalendarActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.edit:
                        return true;
                }
                return false;
            }
        });
    }

}